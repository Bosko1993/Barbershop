Barbershop Termini PWA

Ovo je PWA (instalira se kao aplikacija).

Kako pokrenuti BESPLATNO:
1) GitHub (Pages): napravi repo, uploaduj sve fajlove iz ovog foldera, uključi Pages (Deploy from branch).
2) Cloudflare Pages: upload folder / poveži GitHub, Deploy.
3) Netlify: drag&drop folder.

Nakon što dobiješ link:
- Otvori link na telefonu
- Menu (⋮) → Add to Home screen

Podaci se čuvaju lokalno (u telefonu) u localStorage.
Export/Import služi za backup (JSON fajl).
